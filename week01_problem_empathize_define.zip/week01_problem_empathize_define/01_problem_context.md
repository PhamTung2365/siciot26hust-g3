# 1. Problem & Context

## Bối cảnh
- Vấn đề xảy ra ở đâu?
  + Phòng máy chủ, phòng thí nghiệm, kho thiết bị giá trị cao
- Ai gặp vấn đề?
  + Đội ngũ chuyên viên và nhà quản lý
- Khi nào?
  + Khi nhân viên đang mang vác máy móc nặng
  + Khi có sự cố khẩn cấp xảy ra trong phòng
- Hiện tại xử lý thế nào?
  + Sử dụng thẻ từ hoặc chìa khóa cơ để ra vào.
- Bất tiện/rủi ro/chi phí là gì?
  +  Thẻ từ thiếu đi cơ chế trong việc định danh sinh trắc học độc bản; chúng dễ dàng bị sao chép hoặc mượn tạm, tạo ra nguy cơ người ngoài lọt vào đánh cắp tài sản mà hệ thống quản lý không thể truy vết chính xác danh tính thực sự.

## Problem
Viết 1 đoạn ngắn, không chứa sẵn công nghệ/giải pháp.

## Consequence
Nếu không giải quyết thì hậu quả gì?

## Evidence
| Nội dung | Trạng thái | Nguồn |
|---|---|---|
|  | Observed / Assumed / Target |  |

## Scope sơ bộ
### In scope
-

### Out of scope
-
